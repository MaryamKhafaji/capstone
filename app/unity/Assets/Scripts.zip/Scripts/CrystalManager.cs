using UnityEngine;

public class CrystalManager : MonoBehaviour
{
    public static CrystalManager Instance;

    [Header("Crystal Settings")]
    public int maxCrystals = 100;

    private const string CrystalSaveKey = "PlayerCrystals";

    public int CurrentCrystals { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        LoadCrystals();
    }

    private void LoadCrystals()
    {
        CurrentCrystals = PlayerPrefs.GetInt(
            CrystalSaveKey,
            0
        );

        CurrentCrystals = Mathf.Clamp(
            CurrentCrystals,
            0,
            maxCrystals
        );

        Debug.Log(
            "Loaded crystals: " +
            CurrentCrystals
        );
    }

    public int AddCrystals(int amount)
    {
        CurrentCrystals = Mathf.Clamp(
            CurrentCrystals + amount,
            0,
            maxCrystals
        );

        SaveCrystals();

        return CurrentCrystals;
    }

    private void SaveCrystals()
    {
        PlayerPrefs.SetInt(
            CrystalSaveKey,
            CurrentCrystals
        );

        PlayerPrefs.Save();
    }

    public void ResetCrystals()
    {
        CurrentCrystals = 0;
        SaveCrystals();
    }
}