using UnityEngine;

[ExecuteAlways]
[RequireComponent(typeof(Camera))]
public class MonsterPreviewFramer : MonoBehaviour
{
    public Transform monsterRoot;
    public float padding = 1.3f;

    void LateUpdate()
    {
        FrameMonster();
    }

    void FrameMonster()
    {
        if (monsterRoot == null)
            return;

        Renderer[] renderers =
            monsterRoot.GetComponentsInChildren<Renderer>(true);

        if (renderers.Length == 0)
            return;

        Bounds bounds = renderers[0].bounds;

        for (int i = 1; i < renderers.Length; i++)
        {
            bounds.Encapsulate(renderers[i].bounds);
        }

        Camera previewCamera = GetComponent<Camera>();

        float verticalDistance =
            bounds.extents.y /
            Mathf.Tan(
                previewCamera.fieldOfView *
                0.5f *
                Mathf.Deg2Rad
            );

        float horizontalFov =
            2f * Mathf.Atan(
                Mathf.Tan(
                    previewCamera.fieldOfView *
                    0.5f *
                    Mathf.Deg2Rad
                ) * previewCamera.aspect
            );

        float horizontalDistance =
            bounds.extents.x /
            Mathf.Tan(horizontalFov * 0.5f);

        float distance =
            Mathf.Max(verticalDistance, horizontalDistance) *
            padding +
            bounds.extents.z;

        transform.position =
            bounds.center + Vector3.forward * distance;

        transform.LookAt(bounds.center);
    }
}