
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MonsterHuntUIController : MonoBehaviour
{
    [Header("UI Panels")]
    public GameObject notificationPanel;
    public GameObject monsterIntroPanel;
    public GameObject warningPanel;
    public GameObject distancePanel;

    [Tooltip("Assign GameHUD > CaughtMonsterPanel here.")]
    public GameObject caughtMonsterPanel;

    [Header("Caught Panel UI")]
    public TMP_Text caughtTitleText;
    public TMP_Text caughtRewardsText;
    public Slider crystalBar;
    public TMP_Text crystalBarCountText;

    [Header("Gameplay")]
    public GameObject gameplayRoot;

    [Header("Timing")]
    public float introDuration = 5f;

    [Header("Wrong Direction Warning")]
    public float warningDuration = 5f;
    public bool flashWarning = false;
    public float flashInterval = 0.35f;

    [Header("Crystal Animation")]
    public float crystalFillDuration = 3f;

    private Coroutine huntSequence;
    private Coroutine warningRoutine;
    private Coroutine crystalFillRoutine;

    void Start()
    {
        // Clean starting state without exit animations.
        SetVisibleImmediately(notificationPanel, false);
        SetVisibleImmediately(monsterIntroPanel, false);
        SetVisibleImmediately(warningPanel, false);
        SetVisibleImmediately(distancePanel, false);
        SetVisibleImmediately(caughtMonsterPanel, false);

        if (gameplayRoot != null)
            gameplayRoot.SetActive(false);

        ShowMonsterNotification();
    }

    public void ShowMonsterNotification()
    {
        StopCurrentSequence();
        StopWarning();
        StopCrystalFill();

        SetVisible(notificationPanel, true);
        SetVisible(monsterIntroPanel, false);
        SetVisible(warningPanel, false);
        SetVisible(distancePanel, false);
        SetVisible(caughtMonsterPanel, false);
        SetVisible(gameplayRoot, false);
    }

    public void AcceptHunt()
    {
        StopCurrentSequence();

        huntSequence = StartCoroutine(
            BeginHuntSequence()
        );
    }

    public void IgnoreHunt()
    {
        StopCurrentSequence();
        StopWarning();
        StopCrystalFill();

        SetVisible(notificationPanel, false);
        SetVisible(monsterIntroPanel, false);
        SetVisible(warningPanel, false);
        SetVisible(distancePanel, false);
        SetVisible(caughtMonsterPanel, false);
        SetVisible(gameplayRoot, false);
    }

    private IEnumerator BeginHuntSequence()
    {
        SetVisible(notificationPanel, false);
        SetVisible(monsterIntroPanel, true);
        SetVisible(warningPanel, false);
        SetVisible(caughtMonsterPanel, false);

        yield return new WaitForSeconds(introDuration);

        SetVisible(monsterIntroPanel, false);
        SetVisible(gameplayRoot, true);
        SetVisible(distancePanel, true);

        huntSequence = null;
    }

    public void ShowWrongDirectionWarning()
    {
        if (warningRoutine != null)
            return;

        warningRoutine = StartCoroutine(
            WrongDirectionWarningRoutine()
        );
    }

    public bool IsWarningShowing()
    {
        return warningRoutine != null;
    }

    private IEnumerator WrongDirectionWarningRoutine()
    {
        if (!flashWarning)
        {
            SetVisible(warningPanel, true);

            yield return new WaitForSeconds(
                warningDuration
            );
        }
        else
        {
            float elapsed = 0f;

            while (elapsed < warningDuration)
            {
                if (warningPanel != null)
                {
                    SetVisible(
                        warningPanel,
                        !warningPanel.activeSelf
                    );
                }

                yield return new WaitForSeconds(
                    flashInterval
                );

                elapsed += flashInterval;
            }
        }

        SetVisible(warningPanel, false);

        warningRoutine = null;
    }

    public void ShowCaughtBuDaryah(
        int crystalsEarned,
        int previousCrystals,
        int newCrystals)
    {
        StopCurrentSequence();
        StopWarning();
        StopCrystalFill();

        SetVisible(notificationPanel, false);
        SetVisible(monsterIntroPanel, false);
        SetVisible(warningPanel, false);
        SetVisible(distancePanel, false);

        if (caughtMonsterPanel == null)
        {
            Debug.LogError(
                "CaughtMonsterPanel is NOT assigned!"
            );

            return;
        }

        // Preserve the existing draw order.
        caughtMonsterPanel.transform.SetAsLastSibling();

        // Show with upward slide animation.
        SetVisible(caughtMonsterPanel, true);

        if (caughtTitleText != null)
        {
            caughtTitleText.text =
                "Hooray! You caught Bu Darya!";
        }

        if (caughtRewardsText != null)
        {
            caughtRewardsText.text =
                "Rewards: +" +
                crystalsEarned +
                " Crystals";
        }

        // Always visually start the bar at zero.
        if (crystalBar != null)
        {
            crystalBar.minValue = 0;
            crystalBar.maxValue = 100;
            crystalBar.value = 0;
        }

        if (crystalBarCountText != null)
        {
            crystalBarCountText.text = "0 / 100";
        }

        // Preserve the existing crystal animation.
        crystalFillRoutine = StartCoroutine(
            AnimateCrystalBar(
                0,
                newCrystals
            )
        );
    }

    void SetupCrystalBar(int crystalsEarned)
    {
        if (crystalBar != null)
        {
            crystalBar.minValue = 0f;
            crystalBar.maxValue = crystalsEarned;
            crystalBar.value = 0f;
        }

        if (crystalBarCountText != null)
        {
            crystalBarCountText.text =
                "0 / " + crystalsEarned;
        }
    }

    private IEnumerator AnimateCrystalBar(
        int startCrystals,
        int endCrystals)
    {
        if (crystalBar == null)
            yield break;

        float elapsed = 0f;

        while (elapsed < crystalFillDuration)
        {
            elapsed += Time.deltaTime;

            float progress = Mathf.Clamp01(
                elapsed / crystalFillDuration
            );

            float currentValue = Mathf.Lerp(
                startCrystals,
                endCrystals,
                progress
            );

            crystalBar.value = currentValue;

            if (crystalBarCountText != null)
            {
                crystalBarCountText.text =
                    Mathf.RoundToInt(currentValue) +
                    " / 100";
            }

            yield return null;
        }

        crystalBar.value = endCrystals;

        if (crystalBarCountText != null)
        {
            crystalBarCountText.text =
                endCrystals + " / 100";
        }

        crystalFillRoutine = null;
    }

    void StopCrystalFill()
    {
        if (crystalFillRoutine != null)
        {
            StopCoroutine(crystalFillRoutine);
            crystalFillRoutine = null;
        }
    }

    private void StopWarning()
    {
        if (warningRoutine != null)
        {
            StopCoroutine(warningRoutine);
            warningRoutine = null;
        }

        SetVisible(warningPanel, false);
    }

    private void StopCurrentSequence()
    {
        if (huntSequence != null)
        {
            StopCoroutine(huntSequence);
            huntSequence = null;
        }
    }

    // =====================================================
    // ANIMATED PANEL VISIBILITY
    // =====================================================

    private void SetVisible(GameObject target, bool visible)
    {
        if (target == null)
            return;

        UIPanelAnimator animator =
            target.GetComponent<UIPanelAnimator>();

        if (animator != null)
        {
            if (visible)
                animator.Show();
            else
                animator.Hide();

            return;
        }

        // Objects without an animator keep old behavior.
        target.SetActive(visible);
    }

    private void SetVisibleImmediately(
        GameObject target,
        bool visible)
    {
        if (target == null)
            return;

        UIPanelAnimator animator =
            target.GetComponent<UIPanelAnimator>();

        if (!visible && animator != null)
        {
            animator.HideImmediately();
        }
        else
        {
            target.SetActive(visible);
        }
    }
}
