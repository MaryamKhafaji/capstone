
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OmElSaafHuntController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform mainCamera;

    [Header("Monster Spawn")]
    [SerializeField] private float minSpawnDistance = 5f;
    [SerializeField] private float maxSpawnDistance = 7f;
    [SerializeField] private float monsterHeightBelowCamera = 1.4f;
    [SerializeField] private float maxSpawnAngle = 35f;

    [Header("Collectibles")]
    [SerializeField] private int leafCount = 5;
    [SerializeField] private float leafSize = 0.16f;
    [SerializeField] private float leafHeightBelowCamera = 0.75f;
    [SerializeField] private float brightnessDistance = 3f;
    [SerializeField] private float collectionDistance = 0.7f;
    [SerializeField] private float sidewaysVariation = 0.35f;

    private class Leaf
    {
        public GameObject obj;
        public Material material;
    }

    private readonly List<Leaf> leaves = new List<Leaf>();
    private int collectedCount;
    private bool huntFinished;
    private Vector3 huntStartPosition;
    private bool playerHasMoved;
    [SerializeField] private float minimumMovementToCollect = 0.5f;

    private void OnEnable()
    {
        StartCoroutine(InitializeHunt());
    }

    private IEnumerator InitializeHunt()
    {
        // Give the AR camera time to initialize.
        while (mainCamera == null)
        {
            Camera cam = Camera.main;

            if (cam != null)
                mainCamera = cam.transform;

            yield return null;
        }

        ClearLeaves();

        collectedCount = 0;
        huntFinished = false;


        // Allow the AR camera pose to settle.
        yield return new WaitForSeconds(2f);

        SpawnMonster();
        SpawnLeaves();

        // Start footwear step tracking for Om El-Saaf.
        FootwearStepManager stepManager =
            FindFirstObjectByType<FootwearStepManager>();

        if (stepManager != null)
        {
            stepManager.BeginHunt();
            Debug.Log("OM EL-SAAF: Footwear steps enabled!");
        }
        else
        {
            Debug.LogWarning(
                "OM EL-SAAF: FootwearStepManager not found!"
            );
        }

        huntStartPosition = mainCamera.position;
        playerHasMoved = false;


        Debug.Log("OM EL-SAAF: Player starting at " + huntStartPosition);

        Debug.Log("OM EL-SAAF: Hunt started!");
    }

    private void SpawnMonster()
    {
        Vector3 forward = mainCamera.forward;
        forward.y = 0f;
        forward.Normalize();

        if (forward.sqrMagnitude < 0.001f)
            forward = Vector3.forward;

        float distance = Random.Range(5f, 7f);

        Vector3 spawnPosition =
            mainCamera.position + forward * distance;

        spawnPosition.y =
            mainCamera.position.y - monsterHeightBelowCamera;

        // Set world position ONCE.
        transform.position = spawnPosition;

        // Face the player's position at spawn time.
        Vector3 directionToPlayer =
            mainCamera.position - transform.position;

        directionToPlayer.y = 0f;

        if (directionToPlayer.sqrMagnitude > 0.001f)
        {
            transform.rotation =
                Quaternion.LookRotation(directionToPlayer);
        }

        Debug.Log(
            "OM EL-SAAF: Fixed world position = " +
            transform.position
        );
    }

    /// <summary>
    /// /////////////////////////////////////////////////////////////////////////////////////////
    /// </summary>
    private void SpawnLeaves()
    {
        Vector3 start = mainCamera.position;
        Vector3 end = transform.position;

        Vector3 sideways =
            Vector3.Cross(Vector3.up, end - start).normalized;

        for (int i = 0; i < leafCount; i++)
        {
            float t = Mathf.Lerp(
     0.35f,
     0.90f,
     (i + 0.5f) / leafCount
 );

            Vector3 position = Vector3.Lerp(
                start, end, t
            );

            position += sideways * Random.Range(
                -sidewaysVariation,
                sidewaysVariation
            );

            position.y =
                mainCamera.position.y - leafHeightBelowCamera;

            GameObject sphere =
                GameObject.CreatePrimitive(
                    PrimitiveType.Sphere
                );

            sphere.name = "OmElSaafLeaf_" + (i + 1);
            sphere.transform.position = position;
            sphere.transform.localScale =
                Vector3.one * leafSize;

            // Keep the collectibles organized.
            sphere.transform.SetParent(transform, true);

            Collider collider =
                sphere.GetComponent<Collider>();

            if (collider != null)
                Destroy(collider);

            Shader shader = Shader.Find(
                "Universal Render Pipeline/Lit"
            );

            if (shader == null)
                shader = Shader.Find("Standard");

            Material material = new Material(shader);
            material.EnableKeyword("_EMISSION");

            sphere.GetComponent<Renderer>().material =
                material;

            leaves.Add(new Leaf
            {
                obj = sphere,
                material = material
            });
        }

        Debug.Log(
            "OM EL-SAAF: Spawned " +
            leaves.Count + " leaves."
        );
    }

    private void Update()
    {
        if (mainCamera == null || huntFinished)
            return;
        // Ignore vertical camera movement.
        Vector3 currentPosition = mainCamera.position;
        currentPosition.y = 0f;

        Vector3 startingPosition = huntStartPosition;
        startingPosition.y = 0f;

        float distanceWalked = Vector3.Distance(
            currentPosition,
            startingPosition
        );
        

        foreach (Leaf leaf in leaves)
        {
            if (leaf.obj == null ||
                !leaf.obj.activeSelf)
                continue;

            Vector3 playerPosition = mainCamera.position;
            Vector3 leafPosition = leaf.obj.transform.position;

            // Ignore vertical differences for collection.
            playerPosition.y = 0f;
            leafPosition.y = 0f;

            float distance = Vector3.Distance(
                playerPosition,
                leafPosition
            );

            // Brighter as the player gets closer.
            float brightness = Mathf.Clamp01(
                1f - distance / brightnessDistance
            );

            Color color = Color.Lerp(
                new Color(0.08f, 0.22f, 0.05f),
                new Color(0.5f, 1f, 0.15f),
                brightness
            );

            if (leaf.material.HasProperty("_BaseColor"))
                leaf.material.SetColor(
                    "_BaseColor", color
                );
            else
                leaf.material.color = color;

            leaf.material.SetColor(
                "_EmissionColor",
                color * (brightness * 3f)
            );

            if (distance <= collectionDistance)
            {
                Debug.Log(
    $"COLLECT DEBUG: leaf={leaf.obj.name}, " +
    $"distance={distance:F2}, " +
    $"camera={mainCamera.position}, " +
    $"leafPosition={leaf.obj.transform.position}"
);
                leaf.obj.SetActive(false);
                collectedCount++;

                Debug.Log(
                    "OM EL-SAAF: Leaf collected! " +
                    collectedCount + "/" + leafCount
                );
            }
        }

        if (collectedCount >= leafCount)
        {
            huntFinished = true;
            Debug.Log(
                "OM EL-SAAF: All leaves collected!"
            );
        }
    }

    private void ClearLeaves()
    {
        foreach (Leaf leaf in leaves)
        {
            if (leaf.obj != null)
                Destroy(leaf.obj);

            if (leaf.material != null)
                Destroy(leaf.material);
        }

        leaves.Clear();
    }

    private void OnDisable()
    {
        StopAllCoroutines();
        ClearLeaves();
    }
}
