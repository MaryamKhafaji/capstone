using System;
using System.Collections;
using TMPro;
using UnityEngine;

#if UNITY_ANDROID && !UNITY_EDITOR
using UnityEngine.Android;
#endif

public class FootwearStepManager : MonoBehaviour
{
    [Header("References")]
    public EnergySystem energySystem;
    public TMP_Text connectionStatusText;

    [Header("Editor / BlueStacks Testing")]
    public bool simulateStepsInEditor = true;
    public KeyCode simulatedStepKey = KeyCode.Space;

    private bool huntActive;
    private int fallbackHuntSteps;

#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaClass footwearBridge;
#endif

    public bool HuntActive => huntActive;

    public int HuntSteps =>
        energySystem != null
            ? energySystem.HuntSteps
            : fallbackHuntSteps;

    void Awake()
    {
        if (energySystem == null)
        {
            energySystem = FindFirstObjectByType<EnergySystem>();
        }

        SetStatus("Footwear idle");
    }

    void Update()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (footwearBridge != null)
        {
            // Drain a bounded number of queued BLE messages each frame.
            for (int index = 0; index < 32; index++)
            {
                string message =
                    footwearBridge.CallStatic<string>("pollMessage");

                if (string.IsNullOrEmpty(message))
                {
                    break;
                }

                OnFootwearBleMessage(message);
            }
        }
#endif

#if UNITY_EDITOR
        if (huntActive &&
            simulateStepsInEditor &&
            Input.GetKeyDown(simulatedStepKey))
        {
            RegisterStep();
        }

        if (huntActive &&
            Input.GetKeyDown(KeyCode.R))
        {
            OnFootwearBleMessage("Power");
        }
#endif
    }

    public void BeginHunt()
    {
        fallbackHuntSteps = 0;

        if (energySystem != null)
        {
            energySystem.ResetHuntSteps();
        }

        huntActive = true;

#if UNITY_ANDROID && !UNITY_EDITOR
        StartCoroutine(ConnectOnAndroid());
#else
        SetStatus(
            simulateStepsInEditor
                ? "Simulation ready - press " + simulatedStepKey
                : "Footwear requires an Android build"
        );
#endif
    }

    public int CompleteHunt()
    {
        int completedSteps = HuntSteps;

        if (!huntActive)
        {
            return completedSteps;
        }

        huntActive = false;


        SetStatus(
            "Hunt completed: " +
            completedSteps +
            " steps"
        );

        Debug.Log(
            "FINAL HUNT STEPS: " +
            completedSteps
        );

        return completedSteps;
    }

    public void CancelHunt()
    {
        huntActive = false;

        DisconnectFootwear();

        SetStatus("Hunt cancelled");
    }

    // Called by Android BLE plug-in through UnitySendMessage.
    public void OnFootwearBleMessage(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
        {
            return;
        }

        string cleanMessage = message.Trim();

        if (cleanMessage.StartsWith(
            "STATUS:",
            StringComparison.OrdinalIgnoreCase))
        {
            SetStatus(
                cleanMessage.Substring(
                    "STATUS:".Length
                )
            );

            return;
        }

        if (huntActive &&
            cleanMessage.Equals(
                "Pressed",
                StringComparison.OrdinalIgnoreCase))
        {
            RegisterStep();
            return;
        }

        if (huntActive &&
            cleanMessage.Equals(
                "Power",
                StringComparison.OrdinalIgnoreCase))
        {
            Debug.Log("POWER signal received from footwear.");
            return;
        }
    }

    public void SimulateOneStep()
    {
        if (huntActive)
        {
            RegisterStep();
        }
    }

    void RegisterStep()
    {
        fallbackHuntSteps++;

        if (energySystem != null)
        {
            energySystem.RegisterFootwearStep();
        }

        Debug.Log(
            "FOOTWEAR STEP: " +
            HuntSteps
        );
    }

    void SetStatus(string status)
    {
        if (connectionStatusText != null)
        {
            connectionStatusText.text = status;
        }

        Debug.Log(
            "FOOTWEAR: " +
            status
        );
    }

#if UNITY_ANDROID && !UNITY_EDITOR
    IEnumerator ConnectOnAndroid()
    {
        SetStatus(
            "Requesting Bluetooth permission..."
        );

        int sdkVersion;

        using (
            AndroidJavaClass versionClass =
                new AndroidJavaClass(
                    "android.os.Build$VERSION"
                )
        )
        {
            sdkVersion =
                versionClass.GetStatic<int>(
                    "SDK_INT"
                );
        }

        if (sdkVersion >= 31)
        {
            string[] permissions =
            {
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.BLUETOOTH_CONNECT"
            };

            bool missingPermission = false;

            foreach (string permission in permissions)
            {
                if (!Permission
                    .HasUserAuthorizedPermission(
                        permission
                    ))
                {
                    missingPermission = true;
                    break;
                }
            }

            if (missingPermission)
            {
                Permission.RequestUserPermissions(
                    permissions
                );

                float timeout = 15f;

                while (timeout > 0f)
                {
                    bool allGranted = true;

                    foreach (
                        string permission
                        in permissions
                    )
                    {
                        if (!Permission
                            .HasUserAuthorizedPermission(
                                permission
                            ))
                        {
                            allGranted = false;
                            break;
                        }
                    }

                    if (allGranted)
                    {
                        break;
                    }

                    timeout -=
                        Time.unscaledDeltaTime;

                    yield return null;
                }

                foreach (
                    string permission
                    in permissions
                )
                {
                    if (!Permission
                        .HasUserAuthorizedPermission(
                            permission
                        ))
                    {
                        SetStatus(
                            "Bluetooth permission denied"
                        );

                        yield break;
                    }
                }
            }
        }
        else
        {
            string locationPermission =
                "android.permission.ACCESS_FINE_LOCATION";

            if (!Permission
                .HasUserAuthorizedPermission(
                    locationPermission
                ))
            {
                Permission.RequestUserPermission(
                    locationPermission
                );

                float timeout = 15f;

                while (
                    timeout > 0f &&
                    !Permission
                        .HasUserAuthorizedPermission(
                            locationPermission
                        )
                )
                {
                    timeout -=
                        Time.unscaledDeltaTime;

                    yield return null;
                }

                if (!Permission
                    .HasUserAuthorizedPermission(
                        locationPermission
                    ))
                {
                    SetStatus(
                        "Location permission denied"
                    );

                    yield break;
                }
            }
        }

        if (!huntActive)
        {
            yield break;
        }

        SetStatus(
            "Searching for ESP32_Shoe..."
        );

        try
        {
            footwearBridge =
                new AndroidJavaClass(
                    "com.masar.footwear.FootwearBleBridge"
                );

            using (
                AndroidJavaClass unityPlayer =
                    new AndroidJavaClass(
                        "com.unity3d.player.UnityPlayer"
                    )
            )
            using (
                AndroidJavaObject activity =
                    unityPlayer.GetStatic<
                        AndroidJavaObject
                    >(
                        "currentActivity"
                    )
            )
            {
                footwearBridge.CallStatic(
                    "connect",
                    activity
                );
            }
        }
        catch (Exception exception)
        {
            SetStatus(
                "BLE plug-in unavailable"
            );

            Debug.LogException(
                exception
            );
        }
    }
#endif

    void DisconnectFootwear()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            if (footwearBridge == null)
            {
                footwearBridge =
                    new AndroidJavaClass(
                        "com.masar.footwear.FootwearBleBridge"
                    );
            }

            footwearBridge.CallStatic(
                "disconnect"
            );
        }
        catch (Exception exception)
        {
            Debug.LogWarning(
                "Could not disconnect footwear BLE: " +
                exception.Message
            );
        }
#endif
    }

    void OnDestroy()
    {
        DisconnectFootwear();

#if UNITY_ANDROID && !UNITY_EDITOR
        footwearBridge?.Dispose();
        footwearBridge = null;
#endif
    }
}