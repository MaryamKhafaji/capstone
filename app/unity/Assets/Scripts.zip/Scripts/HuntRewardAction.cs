
using UnityEngine;


public class HuntRewardActions : MonoBehaviour
{
    [Header("Monster Hunt Roots")]
    [SerializeField] private GameObject buDaryaHunt;
    [SerializeField] private GameObject omElSaafHunt;

    // -1 means normal scene startup.
    // 0 means Bu Daryah.
    // 1 means Om El-Saaf.
    private static int nextMonster = -1;

    private void Awake()
    {
        if (nextMonster == -1)
            return;

        int selected = nextMonster;
        nextMonster = -1;

        if (buDaryaHunt == null || omElSaafHunt == null)
        {
            Debug.LogError(
                "Both monster hunt roots must be assigned."
            );
            return;
        }

        // Only the selected monster should run.
        buDaryaHunt.SetActive(selected == 0);
        omElSaafHunt.SetActive(selected == 1);

        Debug.Log(
            selected == 0
                ? "NEW HUNT: Bu Daryah"
                : "NEW HUNT: Om El-Saaf"
        );
    }

    // =================================================
    // RETURN TO FLUTTER
    // =================================================


    public void ReturnToApp()
    {
        Debug.Log("RETURN BUTTON CLICKED");

#if UNITY_ANDROID && !UNITY_EDITOR
    try
    {
        using (AndroidJavaClass unityPlayer =
            new AndroidJavaClass(
                "com.unity3d.player.UnityPlayer"))
        using (AndroidJavaObject activity =
            unityPlayer.GetStatic<AndroidJavaObject>(
                "currentActivity"))
        using (AndroidJavaObject intent =
            new AndroidJavaObject(
                "android.content.Intent"))
        {
            // Open Flutter's MainActivity directly.
            intent.Call<AndroidJavaObject>(
                "setClassName",
                "com.example.masar_plus",
                "com.example.masar_plus.MainActivity"
            );

            // Start Flutter as its own Android task.
            intent.Call<AndroidJavaObject>(
                "addFlags",
                0x10000000
            );

            activity.Call("startActivity", intent);

            Debug.Log(
                "RETURN: Flutter launch requested successfully"
            );
        }
    }
    catch (System.Exception e)
    {
        Debug.LogError(
            "RETURN TO FLUTTER FAILED: " + e
        );
    }
#else
        Debug.Log(
            "RETURN: This button opens Flutter on Android only."
        );
#endif
    }


    // =================================================
    // RANDOM NEXT HUNT
    // =================================================


    public void HuntAgain()
    {
        if (buDaryaHunt == null || omElSaafHunt == null)
        {
            Debug.LogError(
                "HUNT AGAIN: Monster references are missing!"
            );
            return;
        }

        MonsterHuntUIController huntUI =
            GetComponent<MonsterHuntUIController>();

        if (huntUI == null)
        {
            Debug.LogError(
                "HUNT AGAIN: MonsterHuntUIController not found!"
            );
            return;
        }

        // Reset the UI and hide gameplay first.
        huntUI.ShowMonsterNotification();

        // Random selection: 0 = Bu Daryah, 1 = Om El-Saaf.
        int selectedMonster = Random.Range(0, 2);

        buDaryaHunt.SetActive(selectedMonster == 0);
        omElSaafHunt.SetActive(selectedMonster == 1);

        Debug.Log(
            selectedMonster == 0
                ? "NEXT MONSTER: Bu Daryah"
                : "NEXT MONSTER: Om El-Saaf"
        );

        Debug.Log("HUNT AGAIN: Notification restarted!");
    }

}
